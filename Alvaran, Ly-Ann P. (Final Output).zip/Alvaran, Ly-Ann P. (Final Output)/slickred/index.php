<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="design.css" />
<title>Home</title>
</head>

<body>
<div id="container">
		<div id="header">
        	<h1>IPT-1<span class="off">FINAL ACTIVITIES</span></h1>
            <h2>LY-ANN P. ALVARAN</h2>
        </div>   
        
        <div id="menu">
        	<ul>
            	<li class="menuitem"><a href="index.php">Home</a></li>
                <li class="menuitem"><a href="about.php">About</a></li>
              <li class="menuitem"><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        
        <div id="leftmenu">

            <div id="leftmenu_top"></div>

    				<div id="leftmenu_main">    
                    
                        <h3>Links</h3>
                                
                    <ul>
                    <li>
                        <a target="myframe" href="2019-25260 Alvaran, Ly-ann BSIT-2A.pdf">2019-25260 Alvaran, Ly-ann BSIT-2A</a>
                    </li>
                    <li>
                        <a target="myframe" href="Control Structures.pdf">Control Structures</a>
                    </li>
                    <li>
                        <a target="myframe" href="Define & Differentiate Scripting Language and Programming Language.pdf">Scripting and Programming Language</a>
                    </li>
                    <li>
                        <a target="myframe" href="PHP Loops.pdf">PHP Loops</a>
                    </li>
                    <li>
                        <a target="myframe" href="PHP Operators.pdf">PHP OPERATORS</a>
                    </li>
                    <li>
                        <a target="myframe" href="PHP Variable & Constant Variable.pdf">PHP Variable & Constant Variable</a>
                    </li>
                    <li>
                        <a target="myframe" href="github and netlify.pdf">github and netlify</a>
                    </li>
                    <li>
                        <a target="myframe" href="PHP Datatypes.pdf">PHP Datatypes</a>
                    </li>
                   
                    <li>
                        <a target="myframe" href="PHP & History.pdf">PHP & History</a>
                    </li>
                    
                    <li>
                        <a target="myframe" href="XAMPP.pdf">XAMPP</a>
                    </li>
                </ul>
                    </div>
                    
                    
                  <div id="leftmenu_bottom"></div>
        </div>
        <div id="content">
        
        
            <div id="content_top"></div>
            <div id="content_main">
            <h1><center><b><i>SUBMITTED BY: LY-ANN P. ALVARAN
                BSIT-2A</h1></center></i></b>
                <iframe id="frame1" src="" name="myframe" style="width: 100%; height: 100%; border: 0;"></iframe>
            	
            </div>
            <div id="content_bottom"></div>
                
                <div id="footer">
                    <h3><a href="http://www.bryantsmith.com">florida web design</a></h3>
                </div>
        </div>
</div>
</body>
</html>
